/** Automatically generated file. DO NOT MODIFY */
package com.monlift.ca;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}